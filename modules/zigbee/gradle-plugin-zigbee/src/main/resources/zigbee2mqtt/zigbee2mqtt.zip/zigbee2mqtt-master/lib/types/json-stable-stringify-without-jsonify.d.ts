declare module 'json-stable-stringify-without-jsonify' {
    export default function (obj: unknown): string;
}
